These are the frame ranges for each part of the animation:
IDLE    0-338
RUN     339-362
DEATH   363-441
ATACK   442-514  

The weapons aren't rigged, they are parented to the hand bones, so you can change them or remove them easily.
All rigs have the same bone names, so if this is a problem, rename to your liking.
The textures aren't meant to have extra lighting, but a bit of reflections, or shadows is recommended too.

These are just 3 models from a larger set that contains 15 different models:
https://www.turbosquid.com/FullPreview/Index.cfm/ID/1772097

Contact me:
marcosfaci@hotmail.com

